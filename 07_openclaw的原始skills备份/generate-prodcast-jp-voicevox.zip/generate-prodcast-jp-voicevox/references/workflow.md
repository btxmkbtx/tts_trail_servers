# generate-prodcast-jp-voicevox — Workflow (JP script → segmented TTS → PPT-style slides → narrated video)

目标：把一份日文/日语脚本（Markdown 文本）按段落切分；对每段调用本地 VOICEVOX TTS API 生成音频；为每段生成 1 页“要点页/PPT页”；按段落顺序合成讲解视频（mp4）。

## Inputs

- `--input`：Markdown/纯文本脚本（默认按“空行”分段）
- TTS API：
  - `POST http://127.0.0.1:3010/tts` JSON body:
    ```json
    {
      "text": "こんにちは、VOICEVOXのデモへようこそ。",
      "speaker": 81,
      "speedScale": 1.05,
      "pitchScale": 0.03,
      "intonationScale": 1.3,
      "volumeScale": 1.0,
      "outputSamplingRate": 24000
    }
    ```
  - Response example:
    ```json
    {
      "message": "ok",
      "model": "VOICEVOX",
      "speaker": 84,
      "audioUrl": "/outputs/20260401153045.wav"
    }
    ```
  - Download:
    - `GET http://127.0.0.1:3010/outputs/<filename>.wav`

## Outputs (default)

Under the output directory (by default: next to the input file as `<input_stem>_v###`):

- `paragraphs/0001.txt ...` 段落文本（已做轻量 Markdown 清洗，默认不保留 `**` 等强调标记）
- `audio/0001.wav ...` 每段音频
- `durations.json` 每段时长（秒）
- `slides_content.json` 每页 slide 的 `{title, bullets[]}`（与段落一一对应）
- `slides/0001.png ...` 渲染后的 slide 图片
- `final.mp4` 合成视频

## Recommended end-to-end

1–2) Step2 automation (recommended only when stable): split + TTS in one command

```bash
python3 skills/generate-prodcast-jp-voicevox/scripts/step2_auto.py \
  --input /Users/murayamayuta/Desktop/99_private/96_video/03221726.md \
  --out output/prodcast_jp_$(date +%Y%m%d_%H%M) \
  --base-url http://127.0.0.1:3010 \
  --speaker 81 \
  --speed-scale 1.05 --pitch-scale 0.03 --intonation-scale 1.3 \
  --volume-scale 1.0 --output-sampling-rate 24000
```

It will produce:
- `paragraphs/*.txt`
- `audio/*.wav`
- `durations.json`

Important: if batch TTS has been unstable in this environment, do **not** rely on the convenience batch path for production regeneration. Instead, send `paragraphs/0001.txt`, `0002.txt`, ... to `/tts` strictly one by one in order, save each WAV, measure duration, then compose.

(If you prefer manual control, you can still run the split and TTS scripts separately.)

Manual steps:

1) Split Markdown into paragraphs

```bash
python3 skills/generate-prodcast-jp-voicevox/scripts/split_paragraphs.py \
  --input /Users/murayamayuta/Desktop/99_private/96_video/03221726.md \
  --out output/prodcast_jp_$(date +%Y%m%d_%H%M)
```

2) Generate per-paragraph TTS audio

```bash
python3 skills/generate-prodcast-jp-voicevox/scripts/tts_batch.py \
  --in-paragraph-dir output/prodcast_jp_.../paragraphs \
  --out-audio-dir output/prodcast_jp_.../audio \
  --out-durations output/prodcast_jp_.../durations.json \
  --base-url http://127.0.0.1:3010 \
  --speaker 81 \
  --speed-scale 1.05 --pitch-scale 0.03 --intonation-scale 1.3 \
  --volume-scale 1.0 --output-sampling-rate 24000
```

3) Create slide content (1 slide per paragraph, 概要/summary-outline)

Preferred house style:
- Match the strong `minato-news-style` deck style when possible.
- 1 short title + 1–5 bullets per slide (default target: 3).
- Titles should read like Japanese finance/news explainer mini-headlines, not transcript openings.
- Bullets should be compact information points with judgment/meaning, not raw excerpts.
- Reference sample: `references/minato-news-style-sample.json`

Goal: **一段音频对应一页 PPT**，便于后续按每段音频时长换页。

Definition:
- ✅ 概要（summary-outline）= 用自己的话提炼“关键信息/结论/结构”
- ❌ 节选（excerpt）= 直接截取原文句子/片段（常出现省略号、长句、原文措辞）

Save as: `slides_content.json`

### Recommended: curated summaries + validation guardrail

Use a curated `slides_content.json`, then validate before rendering.
For the best results, write/curate slides in this style:
- title: short, assertive, screen-friendly
- bullets: 1–5 depending on density, with 3 as the default target
- content: summary-outline, not sentence fragments, not transcript excerpts
- rule of thumb: short paragraphs can use 1–2 bullets; dense paragraphs can use 4–5 when needed

Then validate:

```bash
python3 skills/generate-prodcast-jp-voicevox/scripts/validate_slides_content.py \
  --slides-json output/prodcast_jp_.../slides_content.json \
  --paragraph-dir output/prodcast_jp_.../paragraphs
```

### Draft generation (allowed, but must be edited)

`auto_slides_from_paragraphs.py` and `summary_slides_from_paragraphs.py` are **draft helpers**.
They can produce a usable first pass, but may still sound like transcript fragments or weak titles.
Do not assume their raw output already matches the `minato-news-style` finance-podcast style; edit or rewrite before final rendering when quality matters.

### Blank template

```bash
python3 skills/generate-prodcast-jp-voicevox/scripts/make_slides_template.py \
  --in-paragraph-dir output/prodcast_jp_.../paragraphs \
  --out output/prodcast_jp_.../slides_content.json
```

4) Render slides to PNG (PowerPoint engine, recommended)

To match the high-quality look of the `podcast_gold_20260321` output, render with Microsoft PowerPoint:

```bash
# 4.1 Build a PPTX from the template
VENV_PPT="/Users/murayamayuta/.openclaw/workspace/.venv_ppt/bin/python"
TEMPLATE=/Users/murayamayuta/.openclaw/workspace/output/podcast_gold_20260321/gold_podcast_summary.pptx
$VENV_PPT skills/generate-prodcast-jp-voicevox/scripts/make_pptx_from_template.py \
  --template "$TEMPLATE" \
  --slides-json output/prodcast_jp_.../slides_content.json \
  --out output/prodcast_jp_.../summary.pptx

# 4.2 Render PPTX -> PDF (PowerPoint) -> PNG
python3 skills/generate-prodcast-jp-voicevox/scripts/pptx_to_slides_png.py \
  --pptx output/prodcast_jp_.../summary.pptx \
  --out-dir output/prodcast_jp_.../slides \
  --width 1920
```

Fallback (no PowerPoint): render directly with ImageMagick using `render_slides.py`.

### Recommended style preset (this project)

To match the approved look (gradient bg + gold underline + rounded dark panel + page indicator; title bold-ish, body regular; all text white):

```bash
python3 skills/generate-prodcast-jp-voicevox/scripts/render_slides.py \
  --slides-json output/prodcast_jp_.../slides_content.json \
  --out-dir output/prodcast_jp_.../slides \
  --size 1920x1080 \
  --title-font .Hiragino-Kaku-Gothic-Interface-W6 \
  --body-font .Hiragino-Kaku-Gothic-Interface-W3 \
  --fg "#ffffff" \
  --accent "#d4af37" \
  --underline-thickness 10 \
  --panel "#0a0f1a" --panel-opacity 92 \
  --shadow "#000000" --shadow-opacity 55 \
  --corner 32 \
  --show-page
```

5) Compose video (slides + audio)

```bash
python3 skills/generate-prodcast-jp-voicevox/scripts/compose_video.py \
  --slides-dir output/prodcast_jp_.../slides \
  --audio-dir output/prodcast_jp_.../audio \
  --durations-json output/prodcast_jp_.../durations.json \
  --out output/prodcast_jp_.../final.mp4
```

## Notes / pitfalls

- 段落过长会导致 TTS 断句不自然：建议在原文里增加标点或拆分段落。
- 分段阶段会先做轻量 Markdown 清洗（例如去掉外层 `**` / `__` 强调、标题/列表标记、inline code 包裹等），让 `paragraphs/*.txt` 尽量保持为纯正文。
- TTS 前仍会再做一层简单的外层强调清洗，避免残留格式标记直接送进语音引擎。
- 统一语速：优先固定 `speaker` 与 `speedScale` / `pitchScale` / `intonationScale` / `volumeScale`，避免段落间听感漂移。
- 视频观感：每页字不要太多；宁可多页。
- If a slide title looks like `こんにちは`, `ここ最近`, or just `一 / 二 / 三`, rewrite it into an informative headline before final rendering.
- 音频文件必须与段落编号严格对应（0001.wav 对 0001.txt）。
