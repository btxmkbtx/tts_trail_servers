#!/usr/bin/env python3
"""End-to-end runner for generate-prodcast-jp-voicevox with guardrails.

Pipeline:
1) step2_auto: split + per-paragraph TTS + durations
2) slides_content.json: MUST be a summary-outline (概要). If --slides-json provided, use it.
   Otherwise, we generate a blank template and stop (to avoid excerpt-like content).
3) validate slides_content.json (fails if excerpt-like)
4) render slides in approved style preset
5) compose final mp4

This prevents regressions where draft/excerpt bullets accidentally get used in the final video.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path


def run(cmd: list[str]) -> None:
    subprocess.check_call(cmd)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument(
        "--out",
        help=(
            "Output directory. If omitted, outputs next to the input file as: "
            "<input_stem>_v### (auto-increment)."
        ),
    )
    ap.add_argument("--slides-json", help="Curated slides_content.json (summary-outline). If omitted, create template and exit.")

    ap.add_argument("--base-url", default="http://127.0.0.1:3010")
    ap.add_argument("--speaker", type=int, default=81)
    ap.add_argument("--speed-scale", type=float, default=1.05)
    ap.add_argument("--pitch-scale", type=float, default=0.03)
    ap.add_argument("--intonation-scale", type=float, default=1.3)
    ap.add_argument("--volume-scale", type=float, default=1.0)
    ap.add_argument("--output-sampling-rate", type=int, default=24000)
    ap.add_argument("--sleep", type=float, default=0.0)

    ap.add_argument("--allow-excerpts", action="store_true", help="Bypass validation (not recommended)")

    args = ap.parse_args()

    input_path = Path(args.input).expanduser().resolve()

    def next_versioned_out_dir() -> Path:
        base_dir = input_path.parent
        stem = input_path.stem
        # Look for existing dirs like <stem>_v001
        existing = []
        for p in base_dir.glob(f"{stem}_v*"):
            if p.is_dir():
                existing.append(p.name)
        max_v = 0
        for name in existing:
            # accept v001 / v1 etc
            parts = name.rsplit("_v", 1)
            if len(parts) != 2:
                continue
            v_str = parts[1]
            if not v_str.isdigit():
                continue
            max_v = max(max_v, int(v_str))
        v = max_v + 1
        return base_dir / f"{stem}_v{v:03d}"

    out_dir = Path(args.out).expanduser().resolve() if args.out else next_versioned_out_dir()
    out_dir.mkdir(parents=True, exist_ok=True)

    skill_dir = Path(__file__).resolve().parent

    # Step2
    run([
        "python3",
        str(skill_dir / "step2_auto.py"),
        "--input",
        str(input_path),
        "--out",
        str(out_dir),
        "--base-url",
        args.base_url,
        "--speaker",
        str(args.speaker),
        "--speed-scale",
        str(args.speed_scale),
        "--pitch-scale",
        str(args.pitch_scale),
        "--intonation-scale",
        str(args.intonation_scale),
        "--volume-scale",
        str(args.volume_scale),
        "--output-sampling-rate",
        str(args.output_sampling_rate),
        "--sleep",
        str(args.sleep),
    ])

    # Step3: require curated slides
    slides_path = out_dir / "slides_content.json"
    if args.slides_json:
        src = Path(args.slides_json).expanduser().resolve()
        dst = slides_path.resolve()
        if src != dst:
            shutil.copyfile(str(src), str(dst))
    else:
        # create blank template and stop
        run([
            "python3",
            str(skill_dir / "make_slides_template.py"),
            "--in-paragraph-dir",
            str(out_dir / "paragraphs"),
            "--out",
            str(slides_path),
        ])
        print("Created slides_content.json template. Please fill it with summary-outline bullets, then rerun with --slides-json.")
        raise SystemExit(3)

    # Validate
    cmd = [
        "python3",
        str(skill_dir / "validate_slides_content.py"),
        "--slides-json",
        str(slides_path),
        "--paragraph-dir",
        str(out_dir / "paragraphs"),
    ]
    if args.allow_excerpts:
        cmd.append("--allow-excerpts")
    run(cmd)

    # Render (approved style preset)
    run([
        "python3",
        str(skill_dir / "render_slides.py"),
        "--slides-json",
        str(slides_path),
        "--out-dir",
        str(out_dir / "slides"),
        "--size",
        "1920x1080",
        "--title-font",
        ".Hiragino-Kaku-Gothic-Interface-W6",
        "--body-font",
        ".Hiragino-Kaku-Gothic-Interface-W3",
        "--fg",
        "#ffffff",
        "--accent",
        "#d4af37",
        "--underline-thickness",
        "10",
        "--panel",
        "#0a0f1a",
        "--panel-opacity",
        "92",
        "--shadow",
        "#000000",
        "--shadow-opacity",
        "55",
        "--corner",
        "32",
        "--show-page",
    ])

    # Compose
    run([
        "python3",
        str(skill_dir / "compose_video.py"),
        "--slides-dir",
        str(out_dir / "slides"),
        "--audio-dir",
        str(out_dir / "audio"),
        "--durations-json",
        str(out_dir / "durations.json"),
        "--out",
        str(out_dir / "final.mp4"),
    ])

    print(f"Wrote: {out_dir / 'final.mp4'}")


if __name__ == "__main__":
    main()
