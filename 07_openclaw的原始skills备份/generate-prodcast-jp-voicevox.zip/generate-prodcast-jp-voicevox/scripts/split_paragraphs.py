#!/usr/bin/env python3
"""Split a markdown/text file into numbered paragraph files.

Paragraph rule (default): blocks separated by one or more blank lines.

Output:
  <out>/paragraphs/0001.txt ...
  <out>/meta.json
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def strip_simple_markdown(text: str) -> str:
    """Remove lightweight markdown formatting while preserving readable text.

    This is intentionally conservative for paragraph/TTS inputs:
    - strip heading/list/blockquote markers at line start
    - unwrap emphasis markers like **text**, __text__, *text*, _text_, ~~text~~
    - unwrap inline code `text`
    - keep link text from [text](url)
    """
    s = text.replace("\r\n", "\n").replace("\r", "\n")

    cleaned_lines: list[str] = []
    for raw in s.split("\n"):
        line = raw.rstrip()
        line = re.sub(r"^\s{0,3}(?:#{1,6}\s+)", "", line)
        line = re.sub(r"^\s{0,3}>\s?", "", line)
        line = re.sub(r"^\s{0,3}(?:[-*+]\s+|\d+[.)]\s+)", "", line)
        cleaned_lines.append(line)

    s = "\n".join(cleaned_lines)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1", s)
    s = re.sub(r"`([^`]+)`", r"\1", s)

    for _ in range(3):
        prev = s
        s = re.sub(r"\*\*(.+?)\*\*", r"\1", s, flags=re.DOTALL)
        s = re.sub(r"__(.+?)__", r"\1", s, flags=re.DOTALL)
        s = re.sub(r"(?<!\*)\*(?!\s)(.+?)(?<!\s)\*(?!\*)", r"\1", s, flags=re.DOTALL)
        s = re.sub(r"(?<!_)_(?!\s)(.+?)(?<!\s)_(?!_)", r"\1", s, flags=re.DOTALL)
        s = re.sub(r"~~(.+?)~~", r"\1", s, flags=re.DOTALL)
        if s == prev:
            break

    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r" ?\n ?", "\n", s)
    return s.strip()


def split_paragraphs(text: str) -> list[str]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    paras: list[list[str]] = []
    cur: list[str] = []
    for line in lines:
        if line.strip() == "":
            if cur:
                paras.append(cur)
                cur = []
            continue
        cur.append(line.rstrip())
    if cur:
        paras.append(cur)

    out: list[str] = []
    for p in paras:
        s = "\n".join(p).strip()
        s = strip_simple_markdown(s)
        if s:
            out.append(s)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Path to .md/.txt")
    ap.add_argument("--out", required=True, help="Output directory")
    args = ap.parse_args()

    in_path = Path(args.input).expanduser()
    out_dir = Path(args.out).expanduser()
    para_dir = out_dir / "paragraphs"
    para_dir.mkdir(parents=True, exist_ok=True)

    text = in_path.read_text(encoding="utf-8")
    paras = split_paragraphs(text)

    items = []
    for i, para in enumerate(paras, start=1):
        name = f"{i:04d}.txt"
        (para_dir / name).write_text(para + "\n", encoding="utf-8")
        items.append({"index": i, "file": f"paragraphs/{name}", "chars": len(para)})

    meta = {
        "input": str(in_path),
        "out": str(out_dir),
        "count": len(items),
        "items": items,
    }
    (out_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"Wrote {len(items)} paragraphs to: {para_dir}")


if __name__ == "__main__":
    main()
