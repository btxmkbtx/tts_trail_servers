#!/usr/bin/env python3
"""Validate that slides_content.json is a *summary outline* (概要) rather than excerpts (节选).

This is a guardrail to prevent accidentally using draft/excerpt-like content when generating
final PPT images/videos.

Heuristics (fail-fast by default):
- No ellipsis characters: '…' or '...'
- Each bullet should be reasonably short (default <= 80 chars)
- Bullets should not be verbatim substrings of the source paragraph text (to avoid copy/excerpt)

Inputs:
- --slides-json: slides_content.json
- --paragraph-dir: directory containing 0001.txt ... (source)

Exit code:
- 0: OK
- 2: validation failed

Use --allow-excerpts to bypass (not recommended).
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def norm(s: str) -> str:
    s = s.strip()
    s = re.sub(r"\s+", " ", s)
    return s


def load_paragraphs(paragraph_dir: Path) -> dict[int, str]:
    out: dict[int, str] = {}
    for p in sorted(paragraph_dir.glob("*.txt")):
        if not p.is_file():
            continue
        try:
            idx = int(p.stem)
        except ValueError:
            continue
        out[idx] = norm(p.read_text(encoding="utf-8", errors="ignore"))
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--slides-json", required=True)
    ap.add_argument("--paragraph-dir", required=True)
    ap.add_argument("--max-bullet-len", type=int, default=80)
    ap.add_argument("--allow-excerpts", action="store_true")
    args = ap.parse_args()

    slides_path = Path(args.slides_json).expanduser().resolve()
    para_dir = Path(args.paragraph_dir).expanduser().resolve()

    slides = json.loads(slides_path.read_text(encoding="utf-8"))
    if not isinstance(slides, list):
        raise SystemExit("slides_json must be a list")

    paras = load_paragraphs(para_dir)

    problems: list[str] = []

    for item in slides:
        if not isinstance(item, dict):
            continue
        idx = int(item.get("index") or 0)
        title = norm(str(item.get("title") or ""))
        bullets = item.get("bullets") or []
        if not isinstance(bullets, list):
            bullets = []

        # Ellipsis check
        if "…" in title or "..." in title:
            problems.append(f"slide {idx:04d}: title contains ellipsis")

        src = paras.get(idx, "")

        for b in bullets:
            b = norm(str(b or ""))
            if not b:
                continue
            if "…" in b or "..." in b:
                problems.append(f"slide {idx:04d}: bullet contains ellipsis: {b}")
            if len(b) > args.max_bullet_len:
                problems.append(f"slide {idx:04d}: bullet too long ({len(b)}>{args.max_bullet_len}): {b}")
            # Excerpt-like: verbatim substring of source paragraph.
            if src and len(b) >= 12 and b in src:
                problems.append(f"slide {idx:04d}: bullet appears verbatim in paragraph (excerpt-like): {b}")

    if problems and not args.allow_excerpts:
        print("VALIDATION_FAILED")
        for p in problems:
            print("- " + p)
        raise SystemExit(2)

    if problems and args.allow_excerpts:
        print("VALIDATION_WARN (allow-excerpts enabled)")
        for p in problems:
            print("- " + p)
        return

    print("OK")


if __name__ == "__main__":
    main()
