#!/usr/bin/env python3
"""Automate Step2: split input markdown into paragraphs, then TTS each paragraph.

This is a convenience wrapper around:
  - split_paragraphs.py
  - tts_batch.py

Configured for a local VOICEVOX-compatible HTTP API.

Outputs under --out:
  paragraphs/*.txt
  audio/*.wav
  durations.json
  meta.json
"""

from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


def run(cmd: list[str]) -> None:
    subprocess.check_call(cmd)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Input .md/.txt")
    ap.add_argument("--out", required=True, help="Output directory")

    ap.add_argument("--base-url", default="http://127.0.0.1:3010")
    ap.add_argument("--speaker", type=int, default=81)
    ap.add_argument("--speed-scale", type=float, default=1.05)
    ap.add_argument("--pitch-scale", type=float, default=0.03)
    ap.add_argument("--intonation-scale", type=float, default=1.3)
    ap.add_argument("--volume-scale", type=float, default=1.0)
    ap.add_argument("--output-sampling-rate", type=int, default=24000)
    ap.add_argument("--sleep", type=float, default=0.0)
    ap.add_argument("--overwrite", action="store_true")

    args = ap.parse_args()

    out_dir = Path(args.out).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    skill_dir = Path(__file__).resolve().parent
    split_script = skill_dir / "split_paragraphs.py"
    tts_script = skill_dir / "tts_batch.py"

    # Step2a: split
    run([
        "python3",
        str(split_script),
        "--input",
        str(Path(args.input).expanduser()),
        "--out",
        str(out_dir),
    ])

    # Step2b: tts batch
    cmd = [
        "python3",
        str(tts_script),
        "--in-paragraph-dir",
        str(out_dir / "paragraphs"),
        "--out-audio-dir",
        str(out_dir / "audio"),
        "--out-durations",
        str(out_dir / "durations.json"),
        "--base-url",
        args.base_url,
        "--speaker",
        str(args.speaker),
        "--speed-scale",
        str(args.speed_scale),
        "--pitch-scale",
        str(args.pitch_scale),
        "--intonation-scale",
        str(args.intonation_scale),
        "--volume-scale",
        str(args.volume_scale),
        "--output-sampling-rate",
        str(args.output_sampling_rate),
        "--sleep",
        str(args.sleep),
    ]
    if args.overwrite:
        cmd.append("--overwrite")
    run(cmd)

    print(f"Done. Outputs in: {out_dir}")


if __name__ == "__main__":
    main()
