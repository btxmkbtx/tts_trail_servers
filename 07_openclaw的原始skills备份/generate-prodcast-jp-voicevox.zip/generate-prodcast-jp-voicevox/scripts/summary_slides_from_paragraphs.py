#!/usr/bin/env python3
"""Generate *summary-outline* slides (概要大纲) from paragraph text.

Goal:
- 1 slide per paragraph
- Title + 3-5 bullets
- Avoid excerpt-like content:
  - No ellipsis
  - No verbatim sentence copies (heuristic)
  - Prefer short, abstracted nouns/phrases

This is a deterministic, non-LLM fallback.
It uses lightweight heuristics:
- sentence split
- keyword-ish extraction (topic markers, nouns-ish chunks)
- aggressive shortening + normalization

NOTE: This is best-effort. For perfect decks, curate slides_content.json manually.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

_SENT_SPLIT_RE = re.compile(r"(?<=[。！？!?])\s+")


def norm(s: str) -> str:
    s = s.strip()
    s = re.sub(r"\s+", " ", s)
    return s


def split_sentences(s: str) -> list[str]:
    s = norm(s)
    if not s:
        return []
    parts = _SENT_SPLIT_RE.split(s)
    if len(parts) == 1:
        parts = re.split(r"(?<=[。！？!?])", s)
    return [p.strip() for p in parts if p.strip()]


def drop_greetings(s: str) -> str:
    return re.sub(r"^(こんにちは|皆さん|みなさん|こんばんは|おはようございます)[、, ]*", "", s)


def no_ellipsis(s: str) -> str:
    return s.replace("…", "").replace("...", "")


def clamp(s: str, max_len: int) -> str:
    s = norm(s)
    s = no_ellipsis(s)
    if len(s) <= max_len:
        return s
    # Hard truncate WITHOUT ellipsis
    return s[:max_len].rstrip()


def abstract_bullet(s: str) -> str:
    """Turn a sentence-ish string into a short outline-ish bullet."""
    s = norm(s)
    s = no_ellipsis(s)
    # Remove leading discourse markers
    s = re.sub(r"^(ただし|ところが|つまり|要するに|結論として|第一に|第二に|第三に|第四に|第五に|また|そして|さらに|一方で)[、, ]*", "", s)
    # Drop sentence-ending and soften to phrase
    s = re.sub(r"(です|ます)(。)?$", "", s)
    s = re.sub(r"。$", "", s)
    # Prefer splitting on commas/markers and keep the first chunk
    s = re.split(r"[、,]", s)[0].strip() if s else s
    # Remove quotes/brackets noise
    s = re.sub(r"[「」『』\[\]\(\)]", "", s)
    return s


def make_title(text: str, sents: list[str], max_len: int) -> str:
    # Try to find a topic-like title by looking for colon-ish or key phrase
    cand = sents[0] if sents else ""
    cand = drop_greetings(cand)
    cand = abstract_bullet(cand)
    # If still long, try a weaker abstraction: pick a short noun-ish chunk
    cand = clamp(cand, max_len)
    return cand


def bullets_from_sentences(src_text: str, sents: list[str], k: int, max_len: int) -> list[str]:
    src_norm = norm(src_text)
    out: list[str] = []

    # Prefer using middle sentences, but abstract them
    cands = sents[1:] if len(sents) > 1 else sents

    for s in cands:
        b = abstract_bullet(s)
        b = clamp(b, max_len)
        if not b:
            continue
        # Avoid verbatim excerpt: if bullet is substring of source, try to compress further
        if len(b) >= 12 and b in src_norm:
            # remove particles and keep shorter head
            b2 = re.sub(r"(が|を|に|へ|で|と|も|から|まで|より)", " ", b)
            b2 = norm(b2)
            b2 = re.split(r"\s+", b2)
            b2 = " ".join(b2[:6]).strip()
            b2 = clamp(b2, max_len)
            if b2 and (len(b2) < len(b)):
                b = b2
        if b and b not in out:
            out.append(b)
        if len(out) >= k:
            break

    # If not enough, add generic structure bullets derived from markers in text
    if len(out) < 3:
        if "リスク" in src_norm and "リスク" not in " ".join(out):
            out.append("主要リスク")
        if "要因" in src_norm and "要因" not in " ".join(out):
            out.append("主な要因")
        if "影響" in src_norm and "影響" not in " ".join(out):
            out.append("想定される影響")

    while len(out) < min(3, k):
        out.append("")

    return out[:k]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-paragraph-dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--bullets", type=int, default=4)
    ap.add_argument("--title-max", type=int, default=24)
    ap.add_argument("--bullet-max", type=int, default=32)
    args = ap.parse_args()

    para_dir = Path(args.in_paragraph_dir).expanduser()
    out_path = Path(args.out).expanduser()

    files = sorted([p for p in para_dir.glob("*.txt") if p.is_file()])
    slides = []
    for p in files:
        idx = int(p.stem)
        text = p.read_text(encoding="utf-8").strip()
        sents = split_sentences(text)
        title = make_title(text, sents, args.title_max)
        bullets = bullets_from_sentences(text, sents, args.bullets, args.bullet_max)
        slides.append({"index": idx, "title": title, "bullets": bullets, "source": str(p)})

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(slides, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote summary-outline slides JSON: {out_path} (slides={len(slides)})")


if __name__ == "__main__":
    main()
