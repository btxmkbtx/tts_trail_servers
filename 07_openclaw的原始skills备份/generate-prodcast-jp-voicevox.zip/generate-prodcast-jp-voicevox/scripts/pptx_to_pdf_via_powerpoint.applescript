on run argv
	set inPptx to item 1 of argv
	set outPdf to item 2 of argv
	tell application "Microsoft PowerPoint"
		activate
		open (POSIX file inPptx)
		delay 1
		set pres to active presentation
		-- Export via 'print out' to a PDF file (PowerPoint rendering engine)
		print out pres print to file outPdf
		close pres saving no
	end tell
end run
