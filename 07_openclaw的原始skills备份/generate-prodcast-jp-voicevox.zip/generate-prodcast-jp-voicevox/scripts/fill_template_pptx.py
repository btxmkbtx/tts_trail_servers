#!/usr/bin/env python3
"""Fill an existing template PPTX with new slide titles/bullets.

This is designed to preserve the exact PowerPoint look (theme/layout/fonts) of a known-good
PPTX like `output/podcast_gold_20260321/gold_podcast_summary.pptx`.

Strategy:
- Load template PPTX
- For the first N slides, overwrite title + body text
- If N > template slide count, append new slides using the template's slide layout
- If N < template slide count, remove the extra slide references (so they won't show)
  (the orphaned slide parts may remain in the file but PowerPoint should open it fine)

Run with the venv that has python-pptx:
  ~/.openclaw/workspace/.venv_ppt/bin/python fill_template_pptx.py ...
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pptx import Presentation


def _set_text(shape, text: str) -> None:
    if shape is None:
        return
    if not getattr(shape, "has_text_frame", False):
        return
    tf = shape.text_frame
    tf.clear()
    tf.text = text


def _set_bullets(shape, bullets: list[str]) -> None:
    if shape is None or not getattr(shape, "has_text_frame", False):
        return
    tf = shape.text_frame
    tf.clear()
    first = True
    for b in bullets:
        b = (b or "").strip()
        if not b:
            continue
        if first:
            p = tf.paragraphs[0]
            first = False
        else:
            p = tf.add_paragraph()
        p.text = b
        p.level = 0


def _find_body_placeholder(slide):
    # Try placeholder type BODY (2)
    for sh in slide.shapes:
        if not getattr(sh, "is_placeholder", False):
            continue
        try:
            if int(sh.placeholder_format.type) == 2:
                return sh
        except Exception:
            continue
    # Fallback: any text frame that's not title
    for sh in slide.shapes:
        if sh == slide.shapes.title:
            continue
        if getattr(sh, "has_text_frame", False):
            return sh
    return None


def _remove_slide(prs: Presentation, slide_index_0: int) -> None:
    # Remove slide reference from sldIdLst
    sldIdLst = prs.slides._sldIdLst  # type: ignore[attr-defined]
    sldId = sldIdLst[slide_index_0]
    rId = sldId.get("r:id")
    sldIdLst.remove(sldId)
    # Also drop relationship so PPT doesn't try to load it
    if rId:
        prs.part.drop_rel(rId)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", required=True)
    ap.add_argument("--slides-json", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    template = Path(args.template).expanduser().resolve()
    slides_json = Path(args.slides_json).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    data = json.loads(slides_json.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise SystemExit("slides_json must be a list")

    prs = Presentation(str(template))

    # Ensure enough slides
    layout = prs.slide_layouts[1] if len(prs.slide_layouts) > 1 else prs.slide_layouts[0]
    while len(prs.slides) < len(data):
        prs.slides.add_slide(layout)

    # Fill
    for i, item in enumerate(data):
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "")
        bullets = item.get("bullets") or []
        if not isinstance(bullets, list):
            bullets = []

        slide = prs.slides[i]
        _set_text(slide.shapes.title, title)
        body = _find_body_placeholder(slide)
        _set_bullets(body, [str(b) for b in bullets])

    # Remove extra slides (from end)
    while len(prs.slides) > len(data):
        _remove_slide(prs, len(prs.slides) - 1)

    prs.save(str(out))
    print(f"Wrote PPTX: {out}")


if __name__ == "__main__":
    main()
