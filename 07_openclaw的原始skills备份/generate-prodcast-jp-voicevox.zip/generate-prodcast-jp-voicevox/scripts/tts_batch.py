#!/usr/bin/env python3
"""Batch-generate WAVs by calling a local VOICEVOX-compatible HTTP API.

API contract (as provided by user):
  POST {baseUrl}/tts -> JSON { message:'ok', audioUrl:'/outputs/<file>.wav', ... }
  GET  {baseUrl}{audioUrl} -> audio bytes

Outputs:
  - audio/0001.wav ...
  - durations.json: { "0001.wav": {"seconds": 12.34, ...}, ... }

Notes:
  - This script only talks to localhost by default. You can override --base-url.
  - Requires ffprobe in PATH.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


def ffprobe_duration_seconds(path: Path) -> float:
    cmd = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        str(path),
    ]
    out = subprocess.check_output(cmd, text=True).strip()
    return float(out)


def http_json_post(url: str, payload: dict, timeout: float = 120.0) -> dict:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8")
    return json.loads(body)


def http_download(url: str, out_path: Path, timeout: float = 300.0) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        data = resp.read()
    out_path.write_bytes(data)


def clean_tts_text(text: str) -> str:
    text = text.strip()
    # Remove simple outer markdown emphasis wrappers like **text** or __text__
    if len(text) >= 4 and text.startswith("**") and text.endswith("**"):
        text = text[2:-2].strip()
    if len(text) >= 4 and text.startswith("__") and text.endswith("__"):
        text = text[2:-2].strip()
    return text


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-paragraph-dir", required=True)
    ap.add_argument("--out-audio-dir", required=True)
    ap.add_argument("--out-durations", required=True)
    ap.add_argument("--base-url", default="http://127.0.0.1:3010")
    ap.add_argument("--speaker", type=int, default=81)
    ap.add_argument("--speed-scale", type=float, default=1.05)
    ap.add_argument("--pitch-scale", type=float, default=0.03)
    ap.add_argument("--intonation-scale", type=float, default=1.3)
    ap.add_argument("--volume-scale", type=float, default=1.0)
    ap.add_argument("--output-sampling-rate", type=int, default=24000)
    ap.add_argument("--sleep", type=float, default=0.0, help="sleep between requests (seconds)")
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()

    para_dir = Path(args.in_paragraph_dir).expanduser()
    out_audio_dir = Path(args.out_audio_dir).expanduser()
    out_durations = Path(args.out_durations).expanduser()

    base = args.base_url.rstrip("/")
    tts_url = base + "/tts"

    files = sorted([p for p in para_dir.glob("*.txt") if p.is_file()])
    if not files:
        print(f"No .txt paragraphs found in: {para_dir}", file=sys.stderr)
        sys.exit(2)

    durations: dict[str, dict] = {}

    for p in files:
        idx = p.stem  # 0001
        out_wav = out_audio_dir / f"{idx}.wav"
        if out_wav.exists() and not args.overwrite:
            sec = ffprobe_duration_seconds(out_wav)
            durations[out_wav.name] = {"seconds": sec, "source": str(p)}
            print(f"[skip] {out_wav.name} ({sec:.2f}s)")
            continue

        text = clean_tts_text(p.read_text(encoding="utf-8"))
        if not text:
            print(f"[warn] empty paragraph: {p}")
            continue

        payload = {
            "text": text,
            "speaker": args.speaker,
            "speedScale": args.speed_scale,
            "pitchScale": args.pitch_scale,
            "intonationScale": args.intonation_scale,
            "volumeScale": args.volume_scale,
            "outputSamplingRate": args.output_sampling_rate,
        }

        print(f"[tts] {p.name} -> {out_wav.name}")
        try:
            resp = http_json_post(tts_url, payload)
        except urllib.error.URLError as e:
            raise SystemExit(f"TTS request failed: {e}\nURL: {tts_url}")

        audio_url = resp.get("audioUrl")
        if not audio_url or not isinstance(audio_url, str):
            raise SystemExit(f"Invalid response (missing audioUrl): {resp}")

        download_url = base + audio_url
        http_download(download_url, out_wav)

        sec = ffprobe_duration_seconds(out_wav)
        durations[out_wav.name] = {
            "seconds": sec,
            "source": str(p),
            "audioUrl": audio_url,
            "downloadUrl": download_url,
            "model": resp.get("model"),
            "speaker": resp.get("speaker", args.speaker),
        }
        print(f"[ok] {out_wav.name} ({sec:.2f}s)")

        if args.sleep > 0:
            time.sleep(args.sleep)

    out_durations.parent.mkdir(parents=True, exist_ok=True)
    out_durations.write_text(json.dumps(durations, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    total = sum(v["seconds"] for v in durations.values() if isinstance(v, dict) and "seconds" in v)
    print(f"Wrote: {out_durations} (segments={len(durations)}, total={total:.2f}s)")


if __name__ == "__main__":
    main()
