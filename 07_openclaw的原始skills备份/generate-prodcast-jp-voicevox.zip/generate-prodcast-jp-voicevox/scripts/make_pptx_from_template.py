#!/usr/bin/env python3
"""Create a PPTX using an existing PPTX template and slides_content.json.

This uses python-pptx, so run it with the venv that has it installed:
  ~/.openclaw/workspace/.venv_ppt/bin/python ...

Inputs:
  --template: a .pptx to reuse theme/layouts from (e.g. podcast_gold_20260321)
  --slides-json: list[{index,title,bullets[]}] or list[{title,bullets[]}] (index optional)

Output:
  --out: generated .pptx

Notes:
- We delete all slides in the template, then rebuild slides.
- Slide layout selection: we try to use the template's first non-title layout (index 1),
  and fall back to layout 0.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pptx import Presentation


def delete_all_slides(prs: Presentation) -> None:
    # python-pptx has no public API for deletion; manipulate the underlying XML.
    sldIdLst = prs.slides._sldIdLst  # type: ignore[attr-defined]
    while len(sldIdLst):
        sldIdLst.remove(sldIdLst[0])


def add_bullets(text_frame, bullets: list[str]) -> None:
    text_frame.clear()
    first = True
    for b in bullets:
        b = (b or "").strip()
        if not b:
            continue
        if first:
            p = text_frame.paragraphs[0]
            first = False
        else:
            p = text_frame.add_paragraph()
        p.text = b
        p.level = 0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", required=True)
    ap.add_argument("--slides-json", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    template = Path(args.template).expanduser().resolve()
    slides_json = Path(args.slides_json).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    prs = Presentation(str(template))
    delete_all_slides(prs)

    data = json.loads(slides_json.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise SystemExit("slides_json must be a list")

    # pick a reasonable layout
    layout_idx = 1 if len(prs.slide_layouts) > 1 else 0
    layout = prs.slide_layouts[layout_idx]

    for i, item in enumerate(data, start=1):
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "")
        bullets = item.get("bullets") or []
        if not isinstance(bullets, list):
            bullets = []

        slide = prs.slides.add_slide(layout)

        # Title
        if slide.shapes.title is not None:
            slide.shapes.title.text = title

        # Body placeholder
        body = None
        for shape in slide.shapes:
            if not shape.is_placeholder:
                continue
            # 1 is typically BODY in many layouts
            try:
                ph_type = shape.placeholder_format.type
            except Exception:
                continue
            # BODY = 2 in pptx.enum.shapes.PP_PLACEHOLDER, but avoid import.
            if int(ph_type) in (2,):
                body = shape
                break
        if body is None:
            # fallback: first placeholder with text frame
            for shape in slide.shapes:
                if getattr(shape, "has_text_frame", False):
                    body = shape
                    break

        if body is not None and getattr(body, "has_text_frame", False):
            add_bullets(body.text_frame, [str(b) for b in bullets])

    prs.save(str(out))
    print(f"Wrote PPTX: {out}")


if __name__ == "__main__":
    main()
