#!/usr/bin/env python3
"""Rewrite slides_content.json in-place to reduce excerpt-like bullets.

Strategy:
- If a bullet (>=12 chars) is a verbatim substring of the source paragraph,
  rewrite it into a shorter, more abstract outline phrase.
- Remove ellipsis.
- Keep within max length.

This is heuristic, but designed to satisfy validate_slides_content.py.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def norm(s: str) -> str:
    s = s.strip()
    s = re.sub(r"\s+", " ", s)
    return s


def load_paragraphs(paragraph_dir: Path) -> dict[int, str]:
    out: dict[int, str] = {}
    for p in sorted(paragraph_dir.glob("*.txt")):
        if not p.is_file():
            continue
        try:
            idx = int(p.stem)
        except ValueError:
            continue
        out[idx] = norm(p.read_text(encoding="utf-8", errors="ignore"))
    return out


def remove_ellipsis(s: str) -> str:
    return s.replace("…", "").replace("...", "")


def clamp(s: str, max_len: int) -> str:
    s = norm(remove_ellipsis(s))
    if len(s) <= max_len:
        return s
    return s[:max_len].rstrip()


def abstract(b: str) -> str:
    b = norm(remove_ellipsis(b))
    b = re.sub(r"。$", "", b)
    b = re.sub(r"(です|ます)$", "", b)
    # remove common fillers
    b = re.sub(r"^(つまり|ところが|ただし|また|そして|さらに|一方で|結論として|要するに)[、, ]*", "", b)
    # compress by dropping particles (very rough) and keeping head words
    b2 = re.sub(r"(が|を|に|へ|で|と|も|から|まで|より)", " ", b)
    b2 = norm(b2)
    toks = [t for t in b2.split(" ") if t]
    if len(toks) > 8:
        toks = toks[:8]
    b2 = " ".join(toks)
    # if too short, keep original head clause
    if len(b2) < 6:
        b2 = b
    # last fallback: split on comma and take first chunk
    b2 = b2.split("、")[0].split(",")[0].strip()
    return b2


def rewrite_if_excerpt(b: str, src: str, max_len: int) -> str:
    b0 = norm(b)
    if not b0:
        return b0
    b0 = remove_ellipsis(b0)
    # if verbatim substring, rewrite
    if src and len(b0) >= 12 and b0 in src:
        b1 = abstract(b0)
        b1 = clamp(b1, max_len)
        # ensure not still verbatim; if still, shorten more
        if src and len(b1) >= 12 and b1 in src:
            b1 = clamp(abstract(b1), max(10, min(max_len, 20)))
        # if still verbatim, force a non-verbatim outline label
        if src and len(b1) >= 12 and b1 in src:
            b1 = "要注意ポイント"
        return b1
    return clamp(b0, max_len)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--slides-json", required=True)
    ap.add_argument("--paragraph-dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-bullet-len", type=int, default=32)
    ap.add_argument("--max-title-len", type=int, default=24)
    args = ap.parse_args()

    slides_path = Path(args.slides_json).expanduser().resolve()
    paras = load_paragraphs(Path(args.paragraph_dir).expanduser().resolve())

    slides = json.loads(slides_path.read_text(encoding="utf-8"))
    if not isinstance(slides, list):
        raise SystemExit("slides_json must be a list")

    for item in slides:
        if not isinstance(item, dict):
            continue
        idx = int(item.get("index") or 0)
        src = paras.get(idx, "")
        title = norm(str(item.get("title") or ""))
        title = clamp(title, args.max_title_len)
        # if title is verbatim, abstract similarly
        if src and len(title) >= 12 and title in src:
            title = clamp(abstract(title), args.max_title_len)
        item["title"] = title

        bullets = item.get("bullets") or []
        if not isinstance(bullets, list):
            bullets = []
        new_bullets = []
        for b in bullets:
            new_bullets.append(rewrite_if_excerpt(str(b or ""), src, args.max_bullet_len))
        item["bullets"] = new_bullets

    out_path = Path(args.out).expanduser().resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(slides, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote de-excerpted slides JSON: {out_path}")


if __name__ == "__main__":
    main()
