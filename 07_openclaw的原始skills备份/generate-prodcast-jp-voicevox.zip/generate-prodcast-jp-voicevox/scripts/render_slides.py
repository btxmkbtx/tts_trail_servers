#!/usr/bin/env python3
"""Render PPT-style slide images from slides_content.json using ImageMagick.

slides_content.json format: list of objects with:
  - index (int)
  - title (str)
  - bullets (list[str])

Output:
  slides/0001.png ...

Requires: `magick` in PATH.
"""

from __future__ import annotations

import argparse
import json
import shlex
import subprocess
from pathlib import Path


def run(cmd: list[str]) -> None:
    subprocess.check_call(cmd)


def parse_size(s: str) -> tuple[int, int]:
    w, h = s.lower().split("x")
    return int(w), int(h)


def escape_for_caption(text: str) -> str:
    # ImageMagick caption: is fairly tolerant; keep it simple.
    # Normalize newlines.
    return text.replace("\r\n", "\n").replace("\r", "\n")


def hex_to_rgba(hex_color: str, alpha_0_1: float) -> str:
    c = hex_color.strip()
    if c.startswith("#"):
        c = c[1:]
    if len(c) == 3:
        c = "".join([ch * 2 for ch in c])
    if len(c) != 6:
        # Fallback: let ImageMagick parse it (may be named color)
        return hex_color
    r = int(c[0:2], 16)
    g = int(c[2:4], 16)
    b = int(c[4:6], 16)
    a = max(0.0, min(1.0, alpha_0_1))
    return f"rgba({r},{g},{b},{a:.3f})"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--slides-json", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--size", default="1920x1080")
    # ImageMagick expects the *Font name* from `magick -list font`, not the macOS UI family name.
    # Use separate fonts for title/body so we can control weight.
    ap.add_argument("--title-font", default=".Hiragino-Kaku-Gothic-Interface-W6")
    ap.add_argument("--body-font", default=".Hiragino-Kaku-Gothic-Interface-W3")
    ap.add_argument("--bg-top", default="#071226", help="top background color")
    ap.add_argument("--bg-bottom", default="#0b1a33", help="bottom background color")
    ap.add_argument("--fg", default="#ffffff", help="foreground color")
    ap.add_argument("--accent", default="#d4af37", help="accent color (gold underline)")
    ap.add_argument("--panel", default="#0a0f1a", help="panel fill color")
    ap.add_argument("--panel-opacity", type=int, default=92, help="0-100")
    ap.add_argument("--shadow", default="#000000", help="shadow color")
    ap.add_argument("--shadow-opacity", type=int, default=55, help="0-100")
    ap.add_argument("--corner", type=int, default=32, help="panel corner radius")
    ap.add_argument("--underline-thickness", type=int, default=10)
    ap.add_argument("--show-page", action="store_true", help="render page indicator like 01/07")
    args = ap.parse_args()

    slides_json = Path(args.slides_json).expanduser()
    out_dir = Path(args.out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    w, h = parse_size(args.size)

    slides = json.loads(slides_json.read_text(encoding="utf-8"))
    if not isinstance(slides, list):
        raise SystemExit("slides_json must be a list")

    for i, s in enumerate(slides, start=1):
        raw_idx = s.get("index")
        idx = int(raw_idx) if raw_idx is not None else i
        title = str(s.get("title") or "")
        bullets = s.get("bullets") or []
        if not isinstance(bullets, list):
            bullets = []

        bullet_lines = []
        for b in bullets:
            b = str(b or "").strip()
            if b:
                bullet_lines.append(f"• {b}")
        body = "\n".join(bullet_lines) if bullet_lines else ""

        title_txt = escape_for_caption(title.strip() or "(title)")
        body_txt = escape_for_caption(body.strip() or "")

        out_path = out_dir / f"{idx:04d}.png"

        # Layout inspired by the reference screenshot:
        # - vertical gradient background
        # - title at top-left
        # - gold underline
        # - rounded dark panel with subtle shadow
        # - bullets inside panel
        # - optional page indicator at bottom-right

        margin_x = int(w * 0.06)
        title_y = int(h * 0.075)
        title_w = int(w * 0.88)
        title_h = int(h * 0.12)

        ul_y = title_y + int(title_h * 0.95)
        ul_x1 = margin_x
        ul_x2 = w - margin_x

        panel_x1 = int(w * 0.05)
        panel_y1 = int(h * 0.20)
        panel_x2 = int(w * 0.95)
        panel_y2 = int(h * 0.88)

        panel_inner_x = panel_x1 + int(w * 0.04)
        panel_inner_y = panel_y1 + int(h * 0.06)
        panel_inner_w = (panel_x2 - panel_x1) - int(w * 0.08)
        panel_inner_h = (panel_y2 - panel_y1) - int(h * 0.10)

        panel_alpha = max(0, min(100, args.panel_opacity))
        shadow_alpha = max(0, min(100, args.shadow_opacity))

        panel_fill = hex_to_rgba(args.panel, panel_alpha / 100.0)
        shadow_bg = hex_to_rgba(args.shadow, shadow_alpha / 100.0)

        cmd = [
            "magick",
            "-size",
            f"{w}x{h}",
            f"gradient:{args.bg_top}-{args.bg_bottom}",
            "-gravity",
            "northwest",
            # Panel layer
            "(",
            "-size",
            f"{w}x{h}",
            "xc:none",
            "-fill",
            panel_fill,
            "-draw",
            f"roundrectangle {panel_x1},{panel_y1} {panel_x2},{panel_y2} {args.corner},{args.corner}",
            ")",
            # Shadow for panel
            "(",
            "+clone",
            "-background",
            shadow_bg,
            "-shadow",
            f"100x18+0+10",
            ")",
            "+swap",
            "-compose",
            "over",
            "-composite",
            # Title
            "(",
            "-size",
            f"{title_w}x{title_h}",
            "-background",
            "none",
            "-fill",
            args.fg,
            "-font",
            args.title_font,
            "-pointsize",
            str(int(h * 0.07)),
            "caption:" + title_txt,
            ")",
            "-geometry",
            f"+{margin_x}+{title_y}",
            "-composite",
            # Underline
            "-stroke",
            args.accent,
            "-strokewidth",
            str(args.underline_thickness),
            "-draw",
            f"line {ul_x1},{ul_y} {ul_x2},{ul_y}",
            # Reset stroke so subsequent text doesn't inherit it
            "-stroke",
            "none",
            # Bullets
            "(",
            "-size",
            f"{panel_inner_w}x{panel_inner_h}",
            "-background",
            "none",
            "-fill",
            args.fg,
            "-font",
            args.body_font,
            "-pointsize",
            str(int(h * 0.045)),
            "caption:" + body_txt,
            ")",
            "-geometry",
            f"+{panel_inner_x}+{panel_inner_y}",
            "-composite",
        ]

        if args.show_page:
            total = len(slides)
            page_txt = f"{idx:02d}/{total:02d}"
            cmd += [
                "(",
                "-size",
                f"{int(w*0.2)}x{int(h*0.05)}",
                "-background",
                "none",
                "-fill",
                "rgba(242,245,255,0.70)",
                "-font",
                args.body_font,
                "-pointsize",
                str(int(h * 0.03)),
                "-gravity",
                "southeast",
                "caption:" + page_txt,
                ")",
                "-gravity",
                "southeast",
                "-geometry",
                f"+{margin_x}+{int(h*0.03)}",
                "-composite",
                "-gravity",
                "northwest",
            ]

        cmd += [str(out_path)]

        run(cmd)
        print(f"Rendered: {out_path}")


if __name__ == "__main__":
    main()
