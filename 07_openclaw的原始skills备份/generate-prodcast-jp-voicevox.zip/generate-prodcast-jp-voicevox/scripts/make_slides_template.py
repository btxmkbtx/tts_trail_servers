#!/usr/bin/env python3
"""Create a slides_content.json template (1 slide per paragraph).

This does NOT summarize. It creates placeholders so an agent/human can fill titles/bullets.

Output format:
[
  {"index": 1, "title": "", "bullets": ["", "", ""]},
  ...
]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-paragraph-dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--bullets", type=int, default=4)
    args = ap.parse_args()

    para_dir = Path(args.in_paragraph_dir).expanduser()
    out = Path(args.out).expanduser()

    files = sorted([p for p in para_dir.glob("*.txt") if p.is_file()])
    slides = []
    for p in files:
        idx = int(p.stem)
        slides.append(
            {
                "index": idx,
                "title": "",
                "bullets": ["" for _ in range(args.bullets)],
                "source": str(p),
            }
        )

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(slides, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote template slides JSON: {out} (slides={len(slides)})")


if __name__ == "__main__":
    main()
