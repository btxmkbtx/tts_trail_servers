#!/usr/bin/env python3
"""Generate "explainer / spoken" slide bullets from paragraph text using heuristics.

This is a deterministic fallback when you don't want to rely on an LLM.
It aims for *口语讲解型* slides:
- 1 slide per paragraph
- title: short, conversational summary (usually first sentence compressed)
- bullets: 3–5 short points, derived from subsequent sentences

Input: a directory of numbered paragraph .txt files (0001.txt ...)
Output: slides_content.json (list of {index,title,bullets,source})

You can edit the resulting JSON manually for best quality.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


_SENT_SPLIT_RE = re.compile(r"(?<=[。！？!?])\s+")


def split_sentences(s: str) -> list[str]:
    s = s.strip()
    if not s:
        return []
    # Normalize whitespace.
    s = re.sub(r"\s+", " ", s)
    # Split on Japanese sentence terminators followed by space.
    parts = _SENT_SPLIT_RE.split(s)
    # If no spaces, fallback: split on 。！？
    if len(parts) == 1:
        parts = re.split(r"(?<=[。！？!?])", s)
    out = []
    for p in parts:
        p = p.strip()
        if p:
            out.append(p)
    return out


def clamp(s: str, max_len: int) -> str:
    s = s.strip()
    if len(s) <= max_len:
        return s
    return s[: max_len - 1].rstrip() + "…"


def make_title(sentences: list[str], max_len: int) -> str:
    if not sentences:
        return ""
    t = sentences[0]
    # Remove common greetings if present.
    t = re.sub(r"^(こんにちは|皆さん|みなさん|こんばんは|おはようございます)[、, ]*", "", t)
    return clamp(t, max_len)


def make_bullets(sentences: list[str], max_bullets: int, max_len: int) -> list[str]:
    # Use sentences[1:] primarily; if only one sentence, try to split by commas.
    cands = sentences[1:]
    if not cands and sentences:
        cands = re.split(r"[、,]", sentences[0])
    bullets: list[str] = []
    for s in cands:
        s = s.strip()
        if not s:
            continue
        s = re.sub(r"^[・•\-\*\s]+", "", s)
        bullets.append(clamp(s, max_len))
        if len(bullets) >= max_bullets:
            break
    return bullets


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-paragraph-dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--bullets", type=int, default=4)
    ap.add_argument("--title-max", type=int, default=28)
    ap.add_argument("--bullet-max", type=int, default=38)
    args = ap.parse_args()

    para_dir = Path(args.in_paragraph_dir).expanduser()
    out = Path(args.out).expanduser()

    files = sorted([p for p in para_dir.glob("*.txt") if p.is_file()])
    slides = []
    for p in files:
        idx = int(p.stem)
        text = p.read_text(encoding="utf-8").strip()
        sents = split_sentences(text)
        title = make_title(sents, args.title_max)
        bullets = make_bullets(sents, args.bullets, args.bullet_max)
        # Ensure at least 3 bullets for readability.
        while len(bullets) < min(3, args.bullets):
            bullets.append("")
        slides.append({"index": idx, "title": title, "bullets": bullets, "source": str(p)})

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(slides, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote explainer-style slides JSON: {out} (slides={len(slides)})")


if __name__ == "__main__":
    main()
