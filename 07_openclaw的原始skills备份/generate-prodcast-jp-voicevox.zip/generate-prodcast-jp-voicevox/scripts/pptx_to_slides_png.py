#!/usr/bin/env python3
"""Render PPTX slides to PNG by:

1) Using Microsoft PowerPoint to 'print out' the PPTX to a PDF (PowerPoint render engine)
2) Converting the PDF pages to PNGs with ImageMagick

This matches the visual style of PowerPoint much better than drawing slides ourselves.

Usage:
  python3 pptx_to_slides_png.py --pptx in.pptx --out-dir slides/ --width 1920

Notes:
- Requires: osascript, Microsoft PowerPoint, magick.
- Output filenames: 0001.png, 0002.png, ... (4-digit, to match audio segments)
"""

from __future__ import annotations

import argparse
import subprocess
import tempfile
from pathlib import Path


def run(cmd: list[str]) -> None:
    subprocess.check_call(cmd)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pptx", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--density", type=int, default=200, help="PDF rasterization density")
    args = ap.parse_args()

    pptx = Path(args.pptx).expanduser().resolve()
    out_dir = Path(args.out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    script = Path(__file__).resolve().parent / "pptx_to_pdf_via_powerpoint.applescript"

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        pdf = td / "slides.pdf"

        # Step 1: PPTX -> PDF via PowerPoint
        run(["osascript", str(script), str(pptx), str(pdf)])

        # Step 2: PDF -> PNGs via ImageMagick
        # This will create slides-0.png, slides-1.png ... in temp; then we rename.
        prefix = td / "slides"
        run([
            "magick",
            "-density",
            str(args.density),
            str(pdf),
            "-resize",
            f"{args.width}x",
            str(prefix) + "-%d.png",
        ])

        pages = sorted(td.glob("slides-*.png"))
        if not pages:
            raise SystemExit("No PNG pages were produced from PDF")

        for i, p in enumerate(pages, start=1):
            out = out_dir / f"{i:04d}.png"
            out.write_bytes(p.read_bytes())

    print(f"Rendered {len(list(out_dir.glob('*.png')))} slides to: {out_dir}")


if __name__ == "__main__":
    main()
