#!/usr/bin/env python3
"""Compose a narrated video from slide PNGs and per-segment WAVs.

- Slides: slides/0001.png ...
- Audio:  audio/0001.wav ...
- Durations: durations.json produced by tts_batch.py

Strategy:
1) Build a concat demuxer list for slide images with per-image duration.
2) Concatenate all WAVs (in order) into one WAV.
3) Mux image-video + audio to final MP4.

Requires: ffmpeg, ffprobe.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from pathlib import Path


def run(cmd: list[str]) -> None:
    subprocess.check_call(cmd)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--slides-dir", required=True)
    ap.add_argument("--audio-dir", required=True)
    ap.add_argument("--durations-json", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--fps", type=int, default=30)
    args = ap.parse_args()

    # Resolve to absolute paths so ffmpeg concat demuxer works even when we
    # generate list files inside a temp directory.
    slides_dir = Path(args.slides_dir).expanduser().resolve()
    audio_dir = Path(args.audio_dir).expanduser().resolve()
    durations_path = Path(args.durations_json).expanduser().resolve()
    out_path = Path(args.out).expanduser().resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    durations = json.loads(durations_path.read_text(encoding="utf-8"))
    # durations keys are like "0001.wav"

    # Build ordered list by index inferred from filenames.
    audio_files = sorted([p for p in audio_dir.glob("*.wav") if p.is_file()])
    if not audio_files:
        raise SystemExit(f"No wav files in: {audio_dir}")

    def dur_for(wav: Path) -> float:
        info = durations.get(wav.name)
        if not info or "seconds" not in info:
            raise SystemExit(f"Missing duration for {wav.name} in {durations_path}")
        return float(info["seconds"])

    slide_files = []
    for wav in audio_files:
        idx = wav.stem
        slide = slides_dir / f"{idx}.png"
        if not slide.exists():
            raise SystemExit(f"Missing slide image for {wav.name}: {slide}")
        slide_files.append(slide)

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        # 1) concat list for images
        concat_imgs = td / "images.txt"
        lines = []
        for wav, slide in zip(audio_files, slide_files, strict=True):
            sec = dur_for(wav)
            # concat demuxer requires quoting.
            lines.append(f"file '{slide.as_posix()}'\n")
            lines.append(f"duration {sec:.6f}\n")
        # repeat last file (concat demuxer quirk)
        lines.append(f"file '{slide_files[-1].as_posix()}'\n")
        concat_imgs.write_text("".join(lines), encoding="utf-8")

        # 2) concat list for audio
        concat_aud = td / "audio.txt"
        aud_lines = [f"file '{p.as_posix()}'\n" for p in audio_files]
        concat_aud.write_text("".join(aud_lines), encoding="utf-8")

        merged_wav = td / "merged.wav"
        run([
            "ffmpeg",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(concat_aud),
            "-c",
            "copy",
            str(merged_wav),
        ])

        # 3) create video from images list
        video_only = td / "video.mp4"
        run([
            "ffmpeg",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(concat_imgs),
            "-r",
            str(args.fps),
            "-pix_fmt",
            "yuv420p",
            "-c:v",
            "libx264",
            str(video_only),
        ])

        # 4) mux audio + video
        run([
            "ffmpeg",
            "-y",
            "-i",
            str(video_only),
            "-i",
            str(merged_wav),
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-shortest",
            str(out_path),
        ])

    print(f"Wrote: {out_path}")


if __name__ == "__main__":
    main()
