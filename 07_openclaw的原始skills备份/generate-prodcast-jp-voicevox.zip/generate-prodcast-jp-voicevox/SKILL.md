---
name: generate-prodcast-jp-voicevox
description: Generate a Japanese narrated PPT-style video (mp4) from a JP Markdown/script by splitting into paragraphs, calling a local VOICEVOX TTS API per paragraph (POST /tts then download the returned audioUrl WAV), summarizing each paragraph into one slide (title + bullets), rendering slide images, and composing a final narrated video with ffmpeg. Use when the user wants the `generate-prodcast-jp` workflow but with a local VOICEVOX server at `http://127.0.0.1:3010/tts`.
---

# generate-prodcast-jp-voicevox

Use this skill to implement the 4-step workflow:

1) Split the input Markdown/text into paragraphs
2) Call the local TTS API per paragraph to generate audio (and measure duration)
3) Create 1 slide per paragraph (title + 1–5 bullets, default target 3)
4) Compose slides + audio into a final narrated mp4

Critical execution rule:
- For production runs on this machine, send paragraph files to TTS **strictly one by one in order** (`0001.txt`, `0002.txt`, ...).
- Do **not** rely on a bulk/batch TTS request strategy after batch instability has been observed.
- If the slide PNGs are already approved, it is valid to regenerate only `paragraphs/`, `audio/`, and `durations.json`, then re-compose with the existing slides.

Default editorial target:
- Prefer the `minato-news-style` (formerly referenced internally as `03242224`): short Japanese finance/news explainer titles, 1–5 bullets (default target 3), clear judgment, no excerpt-like fragments.
- Treat the slide text as *screen copy for a narrated video*, not a shortened transcript.

## Quick start (recommended)

Read: `references/workflow.md`

### ✅ Recommended end-to-end runner (anti-excerpt guardrails)

This runner prevents regressions where `slides_content.json` accidentally becomes **excerpts (节选)**.

```bash
# If you omit --out, it will create the output folder next to the input file as:
#   <input_stem>_v001, _v002, ...
python3 skills/generate-prodcast-jp-voicevox/scripts/make_video.py \
  --input /Users/murayamayuta/Desktop/99_private/96_video/03221726.md \
  --slides-json /path/to/your/slides_content.json

# Or explicitly set --out
python3 skills/generate-prodcast-jp-voicevox/scripts/make_video.py \
  --input /Users/murayamayuta/Desktop/99_private/96_video/03221726.md \
  --out /path/to/output_dir \
  --slides-json /path/to/your/slides_content.json
```

Behavior:
- If you omit `--slides-json`, it will generate a **blank template** and stop (so you can fill true summaries).
- It validates that bullets are **summary-outline (概要)**:
  - no ellipsis (`…` / `...`)
  - bullets are short
  - bullets are not verbatim substrings of the paragraph text
- For production-quality decks, prefer a manually curated `slides_content.json` in the `03242224` style over raw heuristic output.

### Manual pipeline (advanced)

If you prefer manual steps, **validate before rendering/composing**:

```bash
python3 skills/generate-prodcast-jp/scripts/validate_slides_content.py \
  --slides-json "$OUT/slides_content.json" \
  --paragraph-dir "$OUT/paragraphs"
```

(Then render with `render_slides.py` and compose with `compose_video.py`.)

## What to be careful about

- Keep each slide readable: 1 title + 1–5 bullets, with 3 as the default target.
- For short paragraphs, prefer 1–2 strong bullets over padding to 3.
- For dense/long paragraphs, allow 4–5 bullets when that preserves clarity.
- Prefer titles like finance/news explainer mini-headlines rather than transcript fragments (for example: `○○の急落`, `△△が揺らぐ`, `□□の本質`).
- Paragraph ↔ audio ↔ slide must match the same index (`0001`).
- Default TTS service is VOICEVOX at `127.0.0.1:3010`; override `--base-url` if needed.
